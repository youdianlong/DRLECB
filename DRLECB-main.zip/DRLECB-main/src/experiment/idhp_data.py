import pandas as pd
import numpy as np
import os

def convert_file(x):
    x = x.values
    x = x.astype(float)
    return x


def load_and_format_covariates_ihdp(style, path=r"C:/anaconda3/Scripts/drlecb-main"):  # os.path.abspath(__file__)__file__文件的完整路径，os.path.dirname(os.path.abspath(__file__))除去__file__文件的完整路径

    data = np.loadtxt(path, delimiter=',', skiprows=1)  # 在数据集里面不是从第一行来进行遍历
    binfeats = [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    contfeats = [i for i in range(25) if i not in binfeats]

    mu_0, mu_1, x = data[:, 3][:, None], data[:, 4][:, None], data[:, 5:]
    perm = binfeats + contfeats
    x = x[:, perm]
    return x


def load_all_other_crap(style,path=r"E:/anaconda3/Scripts/drlecb-main"):
    # if (style == "train"):
        # data = np.loadtxt(path, delimiter=',')
    # else:
    data = np.loadtxt(path, delimiter=',', skiprows=1) # 在数据集里面从第二行开始遍历
    t, y, y_cf = data[:, 0], data[:, 1][:, None], data[:, 2][:, None]
    mu_0, mu_1, x = data[:, 3][:, None], data[:, 4][:, None], data[:, 5:]
    return t.reshape(-1, 1), y, y_cf, mu_0, mu_1


def main():
    pass


if __name__ == '__main__':
    main()
