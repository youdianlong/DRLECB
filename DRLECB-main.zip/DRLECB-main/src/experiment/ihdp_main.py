from torch import optim
from torch.utils.data import DataLoader, TensorDataset

from src.experiment.models import *
import argparse
from sklearn.preprocessing import StandardScaler
from src.experiment.idhp_data import *
from src.semi_parametric_estimation.ate import *
import time




def _split_output(yt_hat, t, y, y_scaler, x, index, split='train'):


    yt_hat = yt_hat.detach().cpu().numpy()
    q_t0 = y_scaler.inverse_transform(yt_hat[:, 0].reshape(-1, 1).copy())
    q_t1 = y_scaler.inverse_transform(yt_hat[:, 1].reshape(-1, 1).copy())
    g = yt_hat[:, 2].copy() # # g 是平均概率得分

    if yt_hat.shape[1] == 4:
        eps = yt_hat[:, 3][0]
    else:
        eps = np.zeros_like(yt_hat[:, 2])

    y = y_scaler.inverse_transform(y.copy())
    var = "{}: average propensity for treated: {} and untreated: {}".format(split, g[t.squeeze() == 1.].mean(),
                                                                        g[t.squeeze() == 0.].mean()) 

    print(var)

    return {'q_t0': q_t0, 'q_t1': q_t1, 'g': g, 't': t, 'y': y, 'x': x, 'index': index, 'eps': eps}


def train(train_loader, net, optimizer, criterion):

    avg_loss = 0

    # iterate through batches
    for i, data in enumerate(train_loader):
        # get the inputs; data is a list of [inputs, labels]
        inputs, labels, y_train, t_train = data
        # zero the parameter gradients
        optimizer.zero_grad()  # 优化器的梯度归零，以清除上一次迭代中的梯度信息
        # forward + backward + optimize
        outputs = net(inputs, y_train, t_train)
        loss = criterion(outputs, labels, inputs)
        loss_all = net.lld_IT + net.bound_IT + loss
        loss_all.backward()
        optimizer.step()
        avg_loss += loss_all

    return avg_loss / len(train_loader)


def train_(train_loader, net, optimizer, criterion):

    avg_loss = 0

    # iterate through batches
    for i, data in enumerate(train_loader):
        # get the inputs; data is a list of [inputs, labels]
        inputs, labels, y_train, t_train = data
        # zero the parameter gradients
        optimizer.zero_grad()  # 优化器的梯度归零，以清除上一次迭代中的梯度信息
        # forward + backward + optimize
        outputs = net(inputs, y_train, t_train)
        loss = criterion(outputs, labels, inputs)
        # loss_all.backward()
        loss.backward()
        optimizer.step()
        avg_loss += loss

    return avg_loss / len(train_loader)

def make_table_ihdp(train_output, train_truth, train_test='train', n_replication=50):

    truth = train_truth
    # tmle_dict = copy.deepcopy(dict)
    train_output = train_output

    result_dict = train_output[0]  # Assuming you want to access the first element in the list
    q_t0 = result_dict['q_t0']
    q_t1 = result_dict['q_t1']
    g = result_dict['g']
    t = result_dict['t']
    y_dragon = result_dict['y']  # 'y'


    ite_tr = q_t1 - q_t0
    ate_err = abs(truth.mean() - ite_tr)
    pehe_err = np.sqrt(np.mean(np.square(truth - (ite_tr))))

    return ate_err, pehe_err



def train_and_predict_dragons(data_train_dict, data_test_dict, targeted_regularization=True, output_dir='',
                              knob_loss=drlecb_loss_binarycross, ratio=1., dragon='', batch_size=64):

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(device)

    verbose = 0
    data_train = data_train_dict
    data_test = data_test_dict
    verbose = 0
    y_scaler_train = StandardScaler().fit(
        data_train["y_train"])
    y_train_ = y_scaler_train.transform(data_train["y_train"])
    x_train_ = data_train["x_train"]
    t_train_ = data_train["t_train"]

    x_test_ = data_test["x_test"]
    y_scaler_test = StandardScaler().fit(
        data_test["y_test"])
    y_test_ = y_scaler_test.transform(data_test["y_test"])
    t_test_ = data_test["t_test"]
    train_outputs = []
    test_outputs = []

    if dragon == 'DRLECB':
        print("I am here making DRLECB")
        net = DRLECB(x_train_.shape[1]).cuda()


    if targeted_regularization:
        loss = make_tarreg_loss(ratio=ratio, drlecb_loss=knob_loss)
        # print("targeted_regularization:loss")
    else:
        loss = knob_loss


    i = 0
    torch.manual_seed(i)
    np.random.seed(i)
    # Get the data and optionally divide into train and test set（将数据分成训练集和测试集）
    train_index = np.arange(x_train_.shape[0])
    # train_index, test_index = train_test_split(np.arange(x.shape[0]), test_size=0.2, random_state=1)
    test_index = np.arange(x_test_.shape[0])

    x_train, x_test = x_train_[train_index], x_test_[test_index]
    y_train, y_test = y_train_[train_index], y_test_[test_index]
    t_train, t_test = t_train_[train_index], t_test_[test_index]

    yt_train = np.concatenate([y_train, t_train], 1) # 将y的训练集和t的训练集进行拼接
    yt_test = np.concatenate([y_test, t_test], 1) # 将y的训练集和t的训练集进行拼接
    # Create data loader to pass onto training method（创建数据加载器以传递到训练方法）
    tensors_train = torch.from_numpy(x_train).float().cuda(), torch.from_numpy(yt_train).float().cuda(), torch.from_numpy(y_train).float().cuda(), torch.from_numpy(t_train).float().cuda() # torch.from_numpy（）将数组转换为张量
    train_loader = DataLoader(TensorDataset(*tensors_train), batch_size=batch_size)  # TensorDataset是个只用来存放tensor(张量)的数据集，
    # # DataLoader本质上就是一个 iterable（内部定义了 __ iter __ 方法），通过读取Datasets中的数据，组装成一个batch后返回一个tensor

    start_time = time.time()

    epochs1 = 100
    epochs2 = 300


    optimizer_SGD_ = optim.SGD([
        {'params': net.representation_block.parameters()},
        {'params': net.c_predictions.parameters()},
        {'params': net.t0_head.parameters(), 'weight_decay': 0.01},
        {'params': net.t1_head.parameters(), 'weight_decay': 0.01},

    ], lr=1e-6, momentum=0.9)
    optimizer_SGD = optim.SGD([
                               {'params': net.representation_block.parameters()},
                               {'params': net.c_predictions.parameters()},
                               {'params': net.t0_head.parameters(), 'weight_decay': 0.01},
                               {'params': net.t1_head.parameters(), 'weight_decay': 0.01},
                               ], lr=1e-5, momentum=0.9)

    scheduler_SGD_ = optim.lr_scheduler.ReduceLROnPlateau(optimizer=optimizer_SGD_, mode='min', factor=0.5, patience=5,
                                                                                                               threshold=1e-8, cooldown=0, min_lr=0)
    scheduler_SGD = optim.lr_scheduler.ReduceLROnPlateau(optimizer=optimizer_SGD, mode='min', factor=0.5, patience=5,
                                                         threshold=0, cooldown=0, min_lr=0)

    train_loss = 0

    for epoch in range(epochs1):
        # Train on data
        train_loss = train(train_loader, net, optimizer_SGD_, loss)

        scheduler_SGD_.step(train_loss)

    print(f"SGD train loss: {train_loss}")


    # SGD training run
    for epoch2 in range(epochs2):
        # Train on data
        train_loss = train_(train_loader, net, optimizer_SGD, loss)
        # print(epoch2)
        # print(train_loss)
        scheduler_SGD.step(train_loss)

    print(f"SGD train loss: {train_loss}")


    yt_hat_train = net(torch.from_numpy(x_train).float().cuda(), torch.from_numpy(y_train).float().cuda(),
                       torch.from_numpy(t_train).float().cuda())
    yt_hat_test = net(torch.from_numpy(x_test).float().cuda(), torch.from_numpy(y_test).float().cuda(), torch.from_numpy(t_test).float().cuda())


    test_outputs += [_split_output(yt_hat_test, t_test, y_test, y_scaler_test, x_test, test_index, split='test')]
    train_outputs += [_split_output(yt_hat_train, t_train, y_train, y_scaler_train, x_train, train_index, split='train')]

    return test_outputs, train_outputs


def run_ihdp(data_base_dir='./dat/ihdp/csv', output_dir='./DRLECB/result/jobs/', datasets='IHDP',
             knob_loss=drlecb_loss_binarycross,   # 调用有参函数却没传参
             ratio=1., dragon='', reptition = 1, is_targeted_regularization=True):

    print("the datasets is {}".format(datasets)) # 将dragon填充到{}的位置，替代花括号

    replications = reptition
    path = r"C:/Users/dell/Desktop/drlecb-main"
    # data_path = data_base_dir + '/ihdp_npci_' + str(replications) + '.csv'
    # print(data_path)
    if datasets == 'IHDP':
        type = "train"

        # 如果采用IHDP_b数据集，则batchsize = 523

        x_train = load_and_format_covariates_ihdp(type, f"{path}/dat/ihdp/IHDP_1/ihdp_npci_train_{reptition}.csv")
        t_train, y_train, y_cf_train, mu_0_train, mu_1_train = load_all_other_crap(type,
                                                                                   f"{path}/dat/ihdp/IHDP_1/ihdp_npci_train_{reptition}.csv")
        data_train_dict = {
            'x_train': x_train,
            't_train': t_train,
            'y_train': y_train,

        }
        truth_train = mu_1_train - mu_0_train
        # train_ite = mu_1_train.mean() - mu_0_train.mean()
        type = "test"
        x_test = load_and_format_covariates_ihdp(type, f"{path}/dat/ihdp/IHDP_1/ihdp_npci_test_{reptition}.csv")
        t_test, y_test, y_cf_test, mu_0_test, mu_1_test = load_all_other_crap(type,
                                                                          f"{path}/dat/ihdp/IHDP_1/ihdp_npci_test_{reptition}.csv")
        data_test_dict = {
            'x_test': x_test,
            't_test': t_test,
            'y_test': y_test
        }
        truth_test = mu_1_test - mu_0_test
        # test_ite = mu_1_test.mean() - mu_0_test.mean()
        print(f"{path}/dat/ihdp/IHDP/ihdp_npci_{reptition}.csv")
        print("..................................")

        # for is_targeted_regularization in [True, False]:
        if is_targeted_regularization:
            print("Is targeted regularization: {}".format(is_targeted_regularization))
            test_outputs, train_output = train_and_predict_dragons(data_train_dict, data_test_dict,
                                                                   targeted_regularization=is_targeted_regularization,
                                                                   output_dir=output_dir,
                                                                   knob_loss=knob_loss, ratio=ratio, dragon=dragon,
                                                                   batch_size=128)  # batch_size=672

            train_data = np.concatenate([train_output[0]['g'].reshape([-1, 1]), train_output[0]['t'].reshape([-1, 1])],
                                        axis=1)

            data_ex = train_data

            ate_train_min, pehe_train_min = make_table_ihdp(train_output, truth_train, train_test='train')

            ate_test_min, pehe_test_min = make_table_ihdp(test_outputs, truth_test, train_test='test')


            print("ate_train_min:")
            print(ate_train_min)
            print("pehe_train_m")
            print(pehe_train_min)
            print("ate_test_min:")
            print(ate_test_min)
            print("pehe_test_min ：")
            print(pehe_test_min)

        return ate_train_min, pehe_train_min, ate_test_min, pehe_test_min


def turn_knob(data_base_dir, knob,datasets, output_base_dir):
    if datasets == 'IHDP':
        output_dir = os.path.join(output_base_dir, knob)
        ate_train_, pehe_train_, ate_train_tmle_, pehe_train_tmle_, ate__train, pehe__train, ate__test, pehe__test = [], [], [], [], [], [], [], []
        for i in range(0, 4):
            print("Dataset {:d}".format(i + 1))
            if knob == 'DRLECB':
                ate_train_m, pehe_train_m, ate_test_m, pehe_test_m = run_ihdp(
                    data_base_dir=data_base_dir, output_dir=output_dir, datasets='IHDP', dragon='DRLECB', reptition=i + 1,
                    is_targeted_regularization=True)

                # pehe_train_.append(pehe_train_err)
                # pehe_train_tmle_.append(pehe_train_tmle_err)
                ate__train.append(ate_train_m)
                pehe__train.append(pehe_train_m)
                ate__test.append(ate_test_m)
                pehe__test.append(pehe_test_m)


        ate_train_1 = np.mean(ate__train)

        pehe_train_1 = np.mean(pehe__train)

        ate_test_1 = np.mean(ate__test)

        pehe_test_1 = np.mean(pehe__test)

        print("ate_train_1:")
        print(ate_train_1)

        print("pehe_train_1:")
        print(pehe_train_1)

        print("ate_test_1:")
        print(ate_test_1)

        print("pehe_test_1:")
        print(pehe_test_1)




def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_base_dir', type=str, default='./dat/jobs/', help="path to directory LBIDD")
    parser.add_argument('--knob', type=str, default='DRLECB', help="dragonnet or tarnet or nednet")
    parser.add_argument('--datasets', type=str, default='IHDP', help="JOBS or IHDP or TWINS")
    parser.add_argument('--output_base_dir', type=str, default='./dragonnet/result/jobs', help="directory to save the output")

    args = parser.parse_args()

    turn_knob(args.data_base_dir, args.knob, args.datasets, args.output_base_dir)

if __name__ == '__main__':
    main()
