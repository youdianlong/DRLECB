# Setup
import torch
import torch.nn as nn
from torch import nn
import torch.nn.functional as F
# from torch import nn


import math
def maximum_mean_discrepancy_loss(X_treat, X_control):
    """Calculate Maximum Mean Discrepancy loss."""
    return 2 * torch.normal(X_treat.mean(axis=0) - X_control.mean(axis=0))

def get_data_with_treatment_type(data, treatment):
    treatment = treatment.squeeze()
    treated = data[treatment == 1]
    control = data[treatment == 0]
    return treated, control
def binary_classification_loss(concat_true, concat_pred):
    t_true = concat_true[:, 1]
    t_pred = concat_pred[:, 2]
    t_pred = (t_pred + 0.001) / 1.002

    loss = torch.sum(F.binary_cross_entropy_with_logits(t_true, t_pred))  # 交叉熵的计算
    # print(f"T_true: {t_true}")
    # print(f"T_pred: {t_pred}")
    # print(F.binary_cross_entropy(t_true, t_pred))
    print("运行交叉熵函数")
    return loss

# 对事实损失采用均方误差
def regression_loss(concat_true, concat_pred):
    y_true = concat_true[:, 0]
    t_true = concat_true[:, 1]

    y0_pred = concat_pred[:, 0]
    y1_pred = concat_pred[:, 1]

    loss0 = torch.sum((1. - t_true) * torch.square(y_true - y0_pred))
    loss1 = torch.sum(t_true * torch.square(y_true - y1_pred))

    return loss0 + loss1


def ned_loss(concat_true, concat_pred):
    t_true = concat_true[:, 1]

    t_pred = concat_pred[:, 1]
    return torch.sum(F.binary_cross_entropy_with_logits(t_true, t_pred))


def dead_loss(concat_true, concat_pred):
    return regression_loss(concat_true, concat_pred)


def drlecb_loss_binarycross(concat_pred, concat_true):
    return regression_loss(concat_true, concat_pred) + binary_classification_loss(concat_true, concat_pred)


# find out why this is neccessary
# not dicussed
class EpsilonLayer(nn.Module):
    def __init__(self):
        super(EpsilonLayer, self).__init__()

        # building epsilon trainable weight（构建ε可训练权重）
        self.weights = nn.Parameter(torch.Tensor(1, 1)) # 将一个不可训练的tensor转变为可训练的参数（parameter）

        # initializing weight parameter with RandomNormal（用随机数初始化权重）
        nn.init.normal_(self.weights, mean=0, std=0.05)

    def forward(self, inputs):
        return torch.mm(torch.ones_like(inputs)[:, 0:1], self.weights.T) # torch.ones_like(inputs)生成与input形状相同、元素全为1的张量，torch.mm两个矩阵相乘


def make_tarreg_loss(ratio=1., drlecb_loss=drlecb_loss_binarycross):  # 正则化的损失

    def tarreg_ATE_unbounded_domain_loss(concat_pred, concat_true, inputs, use_bce=False, norm_bal_term=True,  use_targ_term=False, b_ratio=1.,use_ipm=True):  # 正则化ATE的边界领域损失\
        if use_bce:
            vanilla_loss = drlecb_loss(concat_pred, concat_true)
        else:
            vanilla_loss = regression_loss(concat_true, concat_pred)
        # vanilla_loss = dragonnet_loss(concat_pred, concat_true)
        input_dim = inputs.shape[1]
        # print(input_dim)
        y_true = concat_true[:, 0]
        t_true = concat_true[:, 1]

        y0_pred = concat_pred[:, 0]
        y1_pred = concat_pred[:, 1]
        t_pred = concat_pred[:, 2]

        epsilons = concat_pred[:, 3]

        t_= t_true / t_pred
        t_reshape = t_.reshape(-1, 1)


        ones_to_sum = t_reshape.repeat(1, input_dim)*inputs  # ti/g(xi) * xi,k

        t__= (1 - t_true) / (1 - t_pred)
        t__reshape = t__.reshape(-1, 1)
        zeros_to_sum = t__reshape.repeat(1, input_dim)*inputs # (1-ti)/1-g(xi) * xi,k

        if norm_bal_term:
            ones_mean = torch.sum(ones_to_sum, dim=0) / torch.sum(t_true / t_pred, dim=0)
            zeros_mean = torch.sum(zeros_to_sum, dim=0) / torch.sum((1 - t_true) / (1 - t_pred), dim=0)

        else:
            ones_mean = torch.sum(ones_to_sum, dim=0)
            zeros_mean = torch.sum(zeros_to_sum, dim=0)

        if use_targ_term:
            loss = ratio * vanilla_loss + b_ratio * torch.nn.MSELoss()(zeros_mean, ones_mean)
        else:
            loss = vanilla_loss

        return loss

    return tarreg_ATE_unbounded_domain_loss

# weight initialization function（权重初始化函数）
def weights_init_normal(params):
    if isinstance(params, nn.Linear):
        torch.nn.init.normal_(params.weight, mean=0.0, std=1.0)  # 从给定均值和标准差的正态分布N(mean, std)中生成值，填充输入的张量或变量
        torch.nn.init.zeros_(params.bias)


# weight initialization function
def weights_init_uniform(params):  # 均匀分布
    if isinstance(params, nn.Linear):
        limit = math.sqrt(6 / (params.weight[1] + params.weight[0]))
        torch.nn.init.uniform_(params.weight, a=-limit, b=limit)
        torch.nn.init.zeros_(params.bias)


class DRLECB(nn.Module):


    def __init__(self, in_features, out_features=[200, 100, 1], mi_min_max='max'):
        super(DRLECB, self).__init__()
        self.out_features = out_features
        self.mi_min_max = mi_min_max
        # representation layers 3 : block1
        # units in kera = out_features


        self.representation_block = nn.Sequential(
            nn.Linear(in_features=in_features, out_features=self.out_features[0]),
            nn.ReLU(),
            nn.Linear(in_features=self.out_features[0], out_features=self.out_features[0]),
            nn.ReLU(),
            nn.Linear(in_features=self.out_features[0], out_features=self.out_features[0]),
            nn.ReLU()
        )



        # -----------Propensity Head
        # in_features=self.out_features[0]
        self.c_predictions = nn.Sequential(nn.Linear(in_features=200, out_features=self.out_features[2]),
                                           nn.Sigmoid())

        # -----------t0 Head
        # in_features=self.out_features[0]
        self.t0_head = nn.Sequential(nn.Linear(in_features=400, out_features=self.out_features[0]),
                                     nn.ReLU(),
                                     nn.Linear(in_features=self.out_features[0], out_features=self.out_features[1]),
                                     nn.ReLU(),
                                     nn.Linear(in_features=self.out_features[1], out_features=self.out_features[2])
                                     )

        # ----------t1 Head
        self.t1_head = nn.Sequential(nn.Linear(in_features=400, out_features=self.out_features[0]),
                                     nn.ReLU(),
                                     nn.Linear(in_features=self.out_features[0], out_features=self.out_features[1]),
                                     nn.ReLU(),
                                     nn.Linear(in_features=self.out_features[1], out_features=self.out_features[2])
                                     )

        # ---------Treatment:
        self.T_prediction = nn.Sequential(nn.Linear(in_features=self.out_features[0], out_features=self.out_features[1]),
                                          nn.ReLU(),
                                          nn.Linear(in_features=self.out_features[1],
                                                    out_features=self.out_features[1]),
                                          nn.ReLU(),
                                          nn.Linear(in_features=self.out_features[1], out_features=self.out_features[2])
                                          )
        self.epsilon = EpsilonLayer()

    def init_params(self, std=1):


        self.representation_block.apply(weights_init_normal)  # 表示块的w和b

        self.c_predictions.apply(weights_init_uniform)  # 预测块g()的神经网络的w和b
        self.t0_head.apply(weights_init_uniform) # t=0的头部网络的w和b
        self.t1_head.apply(weights_init_uniform) # t=1的头部网络的w和b
        # self.T_prediction.apply(weights_init_uniform)

    def forward(self, x, y, t):
        # print(x)
        # x_r = self.rese(x)
        x_I = self.representation_block(x)
        x_C = self.representation_block(x)
        x_A = self.representation_block(x)

        # ------propensity scores
        propensity_head = self.c_predictions(x_C)
        epsilons = self.epsilon(propensity_head)
        # print(f"Prop head: {propensity_head}")
        x_CA = torch.cat((x_C, x_A), 1)
        #T_pre = self.T_prediction(x_I)
        # ------t0
        t0_out = self.t0_head(x_CA)
        # print(f"t0 out: {t0_out}")
        # ------t1
        t1_out = self.t1_head(x_CA)


        self.lld_IT, self.bound_IT, self.mu_IT, self.logvar_IT, self.ws_IT = self.mi_net_IT(x_I, t)


        return torch.cat((t0_out, t1_out, propensity_head, epsilons), 1)  # 将这个几个张量进行组合，按照列的方式




