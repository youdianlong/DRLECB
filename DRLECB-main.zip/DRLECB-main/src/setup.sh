sudo apt update
sudo apt install -y python3-pip git
pip3 install ipdb
pip3 install sklearn
pip3 install numpy
pip3 install scipy
pip3 install matplotlib
pip3 install pandas